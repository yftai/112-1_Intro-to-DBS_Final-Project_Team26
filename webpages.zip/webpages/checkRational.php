<?php
//載入 db.php 檔案，讓我們可以透過它連接資料庫
require_once 'db.php';
$inputID = $_POST['inputID'];
$oldPassword = $_POST['oldPassword'];
$newPassword = $_POST['newPassword'];
?>

<!DOCTYPE html>
<html lang="zh-TW">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>APP STORE - 修改密碼</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        nav form{
            display: flex;
            align-items: center;
        }
        div{
            margin-right: 10px; /* 調整間距 */
        }
        input[type="text"]{
            width: 150px; /* 調整寬度 */
        }
        nav button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		<!--/* 將單選按鈕的外觀設為不顯示 */
		input[type="radio"] {
			display: none;
		}
		form button.large-button{
            padding: 100px 200px; /* 調整內邊距 */
			display: flex;
            align-items: center;
            cursor: pointer;
        }
		img {
            width: 100px; /* 圖片的寬度 */
            height: 100px; /* 圖片的高度 */
            margin-right: 5px; /* 文字和圖片之間的間距 */
        }-->
    </style>
    
  </head>

  <body>
    <nav>
		<br>
		　　APP STORE　　
        <a href="index.php">首頁</a>　　
		<!--<a href="classify.php">分類</a>　　
		<a href="rank.php">排行榜</a>　　
		<a href="review.php">我的評論</a>　　-->
		<a href="signin.php">會員登入</a>　　
		<a href="transformPassword.php">修改密碼</a>　　
		<a href="register.php">會員註冊</a>　　
		<a href="control.php">管理員登入</a>　　
		<br><br>
		<hr>
		<br>
		<form method="POST" action="search.php">
			<div>　　搜尋：<input type="text" name="title"></div>
			<button type="submit">送出</button>
		</form>
		<br>
		<hr>　
    </nav>
	<?php if($inputID == "" || $oldPassword == "" || $newPassword == ""):?>
		<h2>　請輸入帳號、舊密碼、新密碼。</h2>
	<?php else: ?>
		<div>
			<?php
				//定義一個 $datas 陣列變數，準備要放查詢的資料
				$datas = array();

				//將查詢語法當成字串，記錄在$sql變數中
				$sql = "SELECT * FROM `users` WHERE `id` = '$inputID';";

				//用 mysqli_query 方法取執行請求（也就是sql語法），請求後的結果存在 $query 變數中
				$result = mysqli_query($link, $sql);

				//如果請求成功
				if ($result){
					//使用 mysqli_num_rows 方法，判別執行的語法，其取得的資料量，是否大於0
					if (mysqli_num_rows($result) > 0){
						//取得的量大於0代表有資料
						//while迴圈會根據查詢筆數，決定跑的次數
						//mysqli_fetch_assoc 方法取得 一筆值
						while ($row = mysqli_fetch_assoc($result)){
							$datas[] = $row;
						}
					}
					//釋放資料庫查詢到的記憶體
					mysqli_free_result($result);
				}
				else{
					echo "{$sql} 語法執行失敗，錯誤訊息：" . mysqli_error($link);
				}
			?>
			<?php if(!empty($datas)):?>
				<?php if($oldPassword == $datas[0]['password']):?>
					<?php if($newPassword == $datas[0]['password']):?>
						<h2>　新密碼與舊密碼相同。</h2>
					<?php else: ?>
						<?php $sqlupdate = "UPDATE `users` SET `password` = '$newPassword' WHERE `id` = '$inputID';";
						mysqli_query($link, $sqlupdate); ?>
						<h2>　修改密碼成功，請重新登入。</h2>
					<?php endif; ?>
				<?php else: ?>
					<h2>　舊密碼輸入錯誤。</h2>
				<?php endif; ?>
			<?php else: ?>
				<!--為空的，代表沒資料-->
				<h2>　查無此帳號。</h2>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php 
	//結束mysql連線
	mysqli_close($link);
	?>
  </body>
</html>

