<?php
//載入 db.php 檔案，讓我們可以透過它連接資料庫
require_once 'db.php';
?>

<!DOCTYPE html>
<html lang="zh-TW">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>APP STORE - 首頁</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        form{
            display: flex;
            align-items: center;
        }
        div{
            margin-right: 10px; /* 調整間距 */
        }
        input[type="text"]{
            width: 150px; /* 調整寬度 */
        }
        nav button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		/* 將單選按鈕的外觀設為不顯示 */
		input[type="radio"] {
			display: none;
		}
		form button.large-button{
            padding: 100px 200px; /* 調整內邊距 */
			display: flex;
            align-items: center;
            cursor: pointer;
        }
		img {
            width: 100px; /* 圖片的寬度 */
            height: 100px; /* 圖片的高度 */
            margin-right: 5px; /* 文字和圖片之間的間距 */
        }
    </style>
    
  </head>

  <body>
    <nav>
		<br>
		　　APP STORE　　
        <a href="index.php">首頁</a>　　
		<!--<a href="classify.php">分類</a>　　
		<a href="rank.php">排行榜</a>　　
		<a href="review.php">我的評論</a>　　-->
		<a href="signin.php">會員登入</a>　　
		<a href="transformPassword.php">修改密碼</a>　　
		<a href="register.php">會員註冊</a>　　
		<a href="control.php">管理員登入</a>　　
		<br><br>
		<hr>
		<br>
		<form method="POST" action="search.php">
			<div>　　搜尋：<input type="text" name="title"></div>
			<button type="submit">送出</button>
		</form>
		<br>
		<hr>　
    </nav>
	<div>
		<?php
			//定義一個 $datas 陣列變數，準備要放查詢的資料
			$datas = array();

			//將查詢語法當成字串，記錄在$sql變數中
			$sql = "SELECT * FROM `apps` WHERE `rating` = 5.0 ORDER BY `reviews_count` DESC LIMIT 50;";

			//用 mysqli_query 方法取執行請求（也就是sql語法），請求後的結果存在 $query 變數中
			$result = mysqli_query($link, $sql);

			//如果請求成功
			if ($result){
				//使用 mysqli_num_rows 方法，判別執行的語法，其取得的資料量，是否大於0
				if (mysqli_num_rows($result) > 0){
					//取得的量大於0代表有資料
					//while迴圈會根據查詢筆數，決定跑的次數
					//mysqli_fetch_assoc 方法取得 一筆值
					while ($row = mysqli_fetch_assoc($result)){
						$datas[] = $row;
					}
				}
				//釋放資料庫查詢到的記憶體
				mysqli_free_result($result);
			}
			else{
				echo "{$sql} 語法執行失敗，錯誤訊息：" . mysqli_error($link);
			}
		?>
		<?php if(!empty($datas)):?>
			<!--如果 $datas 不是空的，就用print_r印出 $datas
			print_r($datas);-->
			<h2>　推薦應用程式（至多50筆）, 點選前往該應用程式介紹</h2>
			<br>
			<ul>
			<?php foreach($datas as $key => $row):?>
				<?php $num = $key + 1;?>
				<?php echo $num;?>
				<form method="POST" action="<?php echo $row['url']; ?>">
					<div>
						<label>
							<input type="radio" name="radio_option" value="<?php echo $row['id']; ?>">
							<button class="large-button" type="submit">
								<img src="<?php echo $row['icon']; ?>" alt="<?php echo $row['title']; ?>"><br>
								名稱：<?php echo $row['title']; ?><br>
								評分：<?php echo $row['rating']; ?><br>
								評論次數：<?php echo $row['reviews_count']; ?><br>
								標籤：<?php echo $row['tagline']; ?>
							</button>
						</label>
					</div>
				</form>
				<br>
				<br>
			<?php endforeach; ?>
			</ul>
		<?php else: ?>
			<!--為空的，代表沒資料-->
			查無資料;
		<?php endif; ?>
	</div>
  </body>
</html>

