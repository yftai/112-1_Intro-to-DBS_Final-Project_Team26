<?php
//載入 db.php 檔案，讓我們可以透過它連接資料庫
?>

<!DOCTYPE html>
<html lang="zh-TW">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>APP STORE - 會員登入</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        nav form{
            display: flex;
            align-items: center;
        }
        div{
            margin-right: 10px; /* 調整間距 */
        }
        input[type="text"]{
            width: 150px; /* 調整寬度 */
        }
        nav button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		
		<!--/* 將單選按鈕的外觀設為不顯示 */
		input[type="radio"] {
			display: none;
		}
		form button.large-button{
            padding: 100px 200px; /* 調整內邊距 */
			display: flex;
            align-items: center;
            cursor: pointer;
        }
		img {
            width: 100px; /* 圖片的寬度 */
            height: 100px; /* 圖片的高度 */
            margin-right: 5px; /* 文字和圖片之間的間距 */
        }-->
    </style>
    
  </head>

  <body>
    <nav>
		<br>
		　　APP STORE　　
        <a href="index.php">首頁</a>　　
		<!--<a href="classify.php">分類</a>　　
		<a href="rank.php">排行榜</a>　　
		<a href="review.php">我的評論</a>　　-->
		<a href="signin.php">會員登入</a>　　
		<a href="transformPassword.php">修改密碼</a>　　
		<a href="register.php">會員註冊</a>　　
		<a href="control.php">管理員登入</a>　　
		<br><br>
		<hr>
		<br>
		<form method="POST" action="search.php">
			<div>　　搜尋：<input type="text" name="title"></div>
			<button type="submit">送出</button>
		</form>
		<br>
		<hr>　
    </nav>
	<div>
		<h2>　 會員登入</h2>
		<form method="POST" action="check.php">
			<div>　　帳號：<input type="text" name="inputID"></div>
			<div>　　密碼：<input type="text" name="inputPassword"></div><br>
			　　<button type="submit">送出</button>
		</form>
	</div>
  </body>
</html>

