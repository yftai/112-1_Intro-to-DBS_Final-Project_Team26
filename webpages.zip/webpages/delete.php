<?php
//載入 db.php 檔案，讓我們可以透過它連接資料庫
require_once 'db.php';
$inputID = $_POST['inputID'];
?>

<!DOCTYPE html>
<html lang="zh-TW">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>APP STORE - 刪除帳號</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        nav form{
            display: flex;
            align-items: center;
        }
        div{
            margin-right: 10px; /* 調整間距 */
        }
        input[type="text"]{
            width: 150px; /* 調整寬度 */
        }
        nav button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		<!--/* 將單選按鈕的外觀設為不顯示 */
		input[type="radio"] {
			display: none;
		}
		form button.large-button{
            padding: 100px 200px; /* 調整內邊距 */
			display: flex;
            align-items: center;
            cursor: pointer;
        }
		img {
            width: 100px; /* 圖片的寬度 */
            height: 100px; /* 圖片的高度 */
            margin-right: 5px; /* 文字和圖片之間的間距 */
        }-->
		
		table {
            width: 35%; /* 設定表格寬度 */
            margin-left: 60px; /* 移整個表格 */
        }
        th, td {
            padding: 10px; /* 調整單元格內邊距 */
        }
		form button.other-button{
			margin-left: 60px;
			cursor: pointer;
        }
    </style>
    
  </head>

  <body>
    <nav>
		<br>
		　　APP STORE　　
        <a href="index.php">首頁</a>　　
		<!--<a href="classify.php">分類</a>　　
		<a href="rank.php">排行榜</a>　　
		<a href="review.php">我的評論</a>　　-->
		<a href="signin.php">會員登入</a>　　
		<a href="transformPassword.php">修改密碼</a>　　
		<a href="register.php">會員註冊</a>　　
		<a href="control.php">管理員登入</a>　　
		<br><br>
		<hr>
		<br>
		<form method="POST" action="search.php">
			<div>　　搜尋：<input type="text" name="title"></div>
			<button type="submit">送出</button>
		</form>
		<br>
		<hr>　
    </nav>
	<div>
		<?php
			//定義一個 $datas 陣列變數，準備要放查詢的資料
			$datas = array();

			//將查詢語法當成字串，記錄在$sql變數中
			$sql = "DELETE FROM `users` WHERE `id` = '$inputID';";

			//用 mysqli_query 方法取執行請求（也就是sql語法），請求後的結果存在 $query 變數中
			$result = mysqli_query($link, $sql);?>

			<?php if (mysqli_affected_rows($link) > 0):?>
              <h2>　刪除帳號成功，請重新登入管理員帳號確認。</h2>
            <?php elseif (mysqli_affected_rows($link) == 0):?>
              <h2>　無資料刪除。</h2>
            <?php else:?>
              　{$sql} 語法執行失敗，錯誤訊息：" . mysqli_error($link)
			<?php endif;?>
	</div>
	<?php 
	//結束mysql連線
	mysqli_close($link);
	?>
  </body>
</html>

