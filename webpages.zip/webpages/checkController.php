<?php
//載入 db.php 檔案，讓我們可以透過它連接資料庫
require_once 'db.php';
$inputID = $_POST['inputID'];
$inputPassword = $_POST['inputPassword'];
?>

<!DOCTYPE html>
<html lang="zh-TW">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>APP STORE - 管理員登入</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        nav form{
            display: flex;
            align-items: center;
        }
        div{
            margin-right: 10px; /* 調整間距 */
        }
        input[type="text"]{
            width: 150px; /* 調整寬度 */
        }
        nav button{
            padding: 1px 5px; /* 調整內邊距 */
			cursor: pointer;
        }
		<!--
		form button.large-button{
            padding: 100px 200px; /* 調整內邊距 */
			display: flex;
            align-items: center;
            cursor: pointer;
        }
		img {
            width: 100px; /* 圖片的寬度 */
            height: 100px; /* 圖片的高度 */
            margin-right: 5px; /* 文字和圖片之間的間距 */
        }-->

        table {
            width: 35%; /* 設定表格寬度 */
            margin-left: 60px; /* 移整個表格 */
        }

        th, td {
            padding: 10px; /* 調整單元格內邊距 */
        }
		form button.other-button{
			margin-left: 60px;
			cursor: pointer;
        }
		
    </style>
    
  </head>

  <body>
    <nav>
		<br>
		　　APP STORE　　
        <a href="index.php">首頁</a>　　
		<!--<a href="classify.php">分類</a>　　
		<a href="rank.php">排行榜</a>　　
		<a href="review.php">我的評論</a>　　-->
		<a href="signin.php">會員登入</a>　　
		<a href="transformPassword.php">修改密碼</a>　　
		<a href="register.php">會員註冊</a>　　
		<a href="control.php">管理員登入</a>　　
		<br><br>
		<hr>
		<br>
		<form method="POST" action="search.php">
			<div>　　搜尋：<input type="text" name="title"></div>
			<button type="submit">送出</button>
		</form>
		<br>
		<hr>　
    </nav>
	<?php if($inputID == "" || $inputPassword == ""):?>
		<h2>　請輸入管理員帳號、密碼。</h2>
	<?php else: ?>
		<div>
			<?php
				//定義一個 $datas 陣列變數，準備要放查詢的資料
				$datas1 = array();
				$datas2 = array();

				//將查詢語法當成字串，記錄在$sql變數中
				$sql1 = "SELECT * FROM `users` WHERE `id` = '$inputID';";
				$sql2 = "SELECT * FROM `users` WHERE `id` != '110704116';";

				//用 mysqli_query 方法取執行請求（也就是sql語法），請求後的結果存在 $query 變數中
				$result1 = mysqli_query($link, $sql1);
				$result2 = mysqli_query($link, $sql2);

				//如果請求成功
				if ($result1){
					//使用 mysqli_num_rows 方法，判別執行的語法，其取得的資料量，是否大於0
					if (mysqli_num_rows($result1) > 0){
						//取得的量大於0代表有資料
						//while迴圈會根據查詢筆數，決定跑的次數
						//mysqli_fetch_assoc 方法取得 一筆值
						while ($row = mysqli_fetch_assoc($result1)){
							$datas1[] = $row;
						}
						while ($row = mysqli_fetch_assoc($result2)){
							$datas2[] = $row;
						}
					}
					//釋放資料庫查詢到的記憶體
					mysqli_free_result($result1);
					mysqli_free_result($result2);
				}
				else{
					echo "{$sql} 語法執行失敗，錯誤訊息：" . mysqli_error($link);
				}
			?>
			<?php if(!empty($datas1) && $inputID == '110704116'):?>
				<?php if($inputPassword == $datas1[0]['password']):?>
					<h2>　登入成功，</h2>
					<?php echo "　　　　管理員 {$datas1[0]['name']}，你好！（注意：離開此頁面即登出帳號）";?>
					<br><br>
					<?php if(count($datas2) != 0):?>
						<h2>　管理會員帳號，以下為所有會員資料：</h2>
						<form method="POST" action="delete.php">
							<div>
							<table border=1>
								<tr>
									<td>　　</td>
									<td>名稱</td>
									<td>帳號</td>
									<td>密碼</td>
								</tr>
								<?php foreach($datas2 as $key => $row):?>
									<tr>
										<td><label><input type="radio" name="inputID" value="<?php echo $row['id'] ;?>"></td>
										<td><?php echo $row['name'] ;?></td>
										<td><?php echo $row['id'] ;?></td>
										<td><?php echo $row['password'] ;?></td></label>
									</tr>
								<?php endforeach; ?>
							</table>
							</div>
							<br>
							<button class="other-button" type="submit">刪除帳號</button>
							<br>
							<br>
						</form>
					<?php else: ?>
						<h2>　沒有會員註冊帳號。</h2>
					<?php endif; ?>
				<?php else: ?>
					<h2>　密碼錯誤。</h2>
				<?php endif; ?>
			<?php else: ?>
				<!--為空的，代表沒資料-->
				<h2>　查無此管理員帳號。</h2>
			<?php endif; ?>
		</div>
	<?php endif; ?>
  </body>
</html>

